package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;
import browserImplementation.BrowserConfig;
import pages.LandingPage;
import utils.ObjectReader;
import java.util.List;

public class TestMain {
    WebDriver driver;
    LandingPage lp;
    ObjectReader u;
    BrowserConfig bc;
    SoftAssert softAssert;

    @BeforeClass
    public void setUp() {
        bc = new BrowserConfig();
        driver = bc.chooseBrowser();
        u = new ObjectReader();
        lp = new LandingPage(driver);
        softAssert = new SoftAssert();
    }

    @Test(priority = 1)
    public void testNavigationAndTitle() {
        driver.get(u.geturl());
        lp.handlePopup();
        lp.navigateToOffers();
        
        String actualTitle = driver.getTitle();
        String expectedTitle = u.get_ExpectedTitle();
        
        if (actualTitle.equals(expectedTitle)) {
            Reporter.log("Title is matched: Actual and Expected are same.<br>", true);
        } else {
            softAssert.fail("Title mismatch! Found: " + actualTitle);
        }
    }

    @Test(priority = 2, dependsOnMethods = "testNavigationAndTitle")
    public void testBannerText() {
        String actualBanner = lp.getBannerText();
        String expectedBanner = u.get_ExpectedBanner();

        if (actualBanner.contains(expectedBanner)) {
            Reporter.log("Banner text is matched: Actual contains Expected text.<br>", true);
        } else {
            softAssert.fail("Banner text mismatch! Found: " + actualBanner);
        }
    }

    @Test(priority = 3, dependsOnMethods = "testBannerText")
    public void testScreenshotRequirement() {
        lp.takePageScreenshot("yatra_requirement_proof");
        Reporter.log("Screenshot captured successfully.<br>", true);
    }

    @Test(priority = 4)
    public void testHolidayPackages() {
        List<WebElement> packages = lp.getPackages();
        Reporter.log("Total holiday packages found: " + packages.size() + "<br>", true);
        
        for (int i = 0; i < 5 && i < packages.size(); i++) {
            Reporter.log((i + 1) + ". " + packages.get(i).getText() + "<br>", true);
        }
        
        softAssert.assertAll(); // All testing failures are reported here
    }

    @AfterClass
    public void tearDown() {
        if (bc != null) {
            bc.closeBrowser();
            Reporter.log("Browser closed.<br>", true);
        }
    }
}