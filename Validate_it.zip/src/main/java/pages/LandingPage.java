package pages;

import java.io.File;
import java.time.Duration;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import utils.ObjectReader;

public class LandingPage {
    WebDriver driver;
    WebDriverWait wait;
    ObjectReader u;

    // Declarations
    By popupCloseX;
    By offersLink;
    By bannerHeading;
    By holidaysLink;
    By packageTitles;

    public LandingPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.u = new ObjectReader();

        // Initializing Locators from properties
        this.popupCloseX = By.xpath(u.getLocator("popupCloseX"));
        this.offersLink = By.xpath(u.getLocator("offersLink"));
        this.bannerHeading = By.xpath(u.getLocator("bannerHeading"));
        this.holidaysLink = By.linkText(u.getLocator("holidaysLink"));
        this.packageTitles = By.cssSelector(u.getLocator("packageTitles"));
    }

    // Callings
    public void handlePopup() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(popupCloseX)).click();
            Reporter.log("Initial popup closed.<br>", true);
        } catch (Exception e) {
            Reporter.log("No popup appeared.<br>", true);
        }
    }

    public void navigateToOffers() {
        WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(offersLink));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        String parent = driver.getWindowHandle();
        for (String handle : driver.getWindowHandles()) {
            if (!handle.equals(parent)) {
                driver.switchTo().window(handle);
            }
        }
    }

    public String getBannerText() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(bannerHeading)).getText();
    }

    public void takePageScreenshot(String fileName) {
        try {
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String path = System.getProperty("user.dir") + File.separator + "Screenshots" + File.separator + fileName + ".png";
            FileUtils.copyFile(src, new File(path));
        } catch (Exception e) {
            Reporter.log("Screenshot failed.<br>", true);
        }
    }

    public List<WebElement> getPackages() {
        wait.until(ExpectedConditions.elementToBeClickable(holidaysLink)).click();
        return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(packageTitles));
    }
}