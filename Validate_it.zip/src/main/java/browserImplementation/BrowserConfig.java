package browserImplementation;

import java.util.Scanner;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserConfig {
    WebDriver driver;

    @SuppressWarnings("resource")
    public WebDriver chooseBrowser() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Select a Browser to Launch: ");
        System.out.println("1. Chrome");
        System.out.println("2. Edge");
        System.out.print("Enter your choice: ");
        
        String choice = sc.nextLine();

        switch (choice) {
            case "1":
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--disable-notifications");
                driver = new ChromeDriver(options);
                break;
            case "2":
                driver = new EdgeDriver();
                break;
            default:
                throw new RuntimeException("Invalid selection: " + choice);
        }
        driver.manage().window().maximize();
        return driver;
    }

    public void closeBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }
}