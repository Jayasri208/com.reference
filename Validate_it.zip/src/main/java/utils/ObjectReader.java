package utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ObjectReader {
    Properties pro;

    public ObjectReader() {
        try {
            String path = System.getProperty("user.dir") + File.separator + "ObjectRepository" + File.separator + "object.properties";
            FileInputStream fis = new FileInputStream(path);
            pro = new Properties();
            pro.load(fis);
            fis.close();
        } catch (Exception e) {
            System.err.println("Error: Could not load properties file.");
        }
    }

    // Existing methods
    public String geturl() { return pro.getProperty("BaseUrl"); }
    public String get_ExpectedTitle() { return pro.getProperty("ExpectedTitle"); }
    public String get_ExpectedBanner() { return pro.getProperty("ExpectedBanner"); }

    // New generic method to get any locator value
    public String getLocator(String key) {
        return pro.getProperty(key);
    }
}